//
//  Saving+CoreDataClass.swift
//  SavingimgCoreData
//
//  Created by A on 4/19/22.
//
//

import Foundation
import CoreData

@objc(Saving)
public class Saving: NSManagedObject {

}
